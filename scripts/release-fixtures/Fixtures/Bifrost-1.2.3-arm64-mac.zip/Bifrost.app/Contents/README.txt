A fixture of the update ZIP. It is not an app.
